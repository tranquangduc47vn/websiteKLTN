<?php
/**
 * Copy file này thành mail.local.php và điền thông tin Gmail App Password.
 * Không commit mail.local.php (chứa mật khẩu).
 */
$mail_from_email = 'clone.hcm001@gmail.com';
$mail_from_name  = 'qD Design';
$mail_smtp_host  = 'smtp.gmail.com';
$mail_smtp_port  = 587;
$mail_smtp_user  = 'clone.hcm001@gmail.com';
$mail_smtp_pass  = 'bjuuyhtqsklwudre';
$mail_smtp_secure = 'tls';
