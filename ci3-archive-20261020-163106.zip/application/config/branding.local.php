<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$site_logo = 'branding/site-logo.png';
